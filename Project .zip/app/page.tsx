export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-10">
      <h1 className="text-5xl font-bold mb-6 text-pink-500">
        Felixworlddmeet
      </h1>

      <p className="text-center text-lg max-w-xl mb-10">
        Meet people worldwide, make friends, chat, video call and build real connections.
      </p>

      <div className="flex gap-4">
        <button className="bg-pink-600 px-6 py-3 rounded-xl">
          Start Matching
        </button>

        <button className="bg-white text-black px-6 py-3 rounded-xl">
          Create Profile
        </button>
      </div>
    </main>
  );
}